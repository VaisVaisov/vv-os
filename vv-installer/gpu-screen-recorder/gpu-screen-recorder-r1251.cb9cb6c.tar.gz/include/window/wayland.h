#ifndef GSR_WINDOW_WAYLAND_H
#define GSR_WINDOW_WAYLAND_H

#include "window.h"

gsr_window* gsr_window_wayland_create(void);

#endif /* GSR_WINDOW_WAYLAND_H */
